import React from 'react';

function PageNotFound(props) {
    return (
        <div>
            <p className='display-1'>404 ERROR</p>
            <p className='display-5'>Page Not Found</p>
        </div>
    );
}

export default PageNotFound;