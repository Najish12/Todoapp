import React from 'react';

function Profile(props) {
    return (
        <div>
            Profile
        </div>
    );
}

export default Profile;